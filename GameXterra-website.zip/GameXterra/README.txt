# GameXterra

A responsive dark futuristic gaming discovery website.

## Run locally
1. Keep `index.html`, `style.css`, and `script.js` in the same folder.
2. Open `index.html` in a modern browser.

## Features
- Responsive desktop and mobile layout
- Game search and genre filters
- Game detail pop-up cards
- Mobile navigation menu
- Animated CSS portal artwork
- No build tools or installation required

## Publish
Upload the three files to a GitHub repository and enable GitHub Pages in the repository's Settings → Pages. This is a static front-end demo; real accounts, databases, and community features would need a secure backend.
