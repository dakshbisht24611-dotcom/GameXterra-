const games = {
  "Minecraft": "Build, explore, and shape a block-based world at your own pace. Genre: Sandbox / Creative.",
  "Grand Theft Auto V": "Explore a sprawling open-world action adventure. Genre: Action / Open world.",
  "Valorant": "A tactical team-based shooter where strategy and precision matter. Genre: Tactical shooter.",
  "Fortnite": "Drop into a colorful battle royale experience and build your strategy. Genre: Action / Battle royale.",
  "PUBG Battlegrounds": "Compete to be the last player or squad standing. Genre: Shooter / Survival.",
  "Call of Duty": "A long-running action shooter series with multiple play modes. Genre: Shooter / FPS.",
  "Free Fire": "A fast-paced mobile battle royale experience. Genre: Action / Battle royale.",
  "Roblox": "Explore experiences and create worlds across a huge community platform. Genre: Adventure / Creative."
};

const searchInput = document.getElementById('gameSearch');
const filterList = document.getElementById('filterList');
const gameCards = [...document.querySelectorAll('.game-card')];
const emptyState = document.getElementById('emptyState');
let activeFilter = 'All';

function updateGames() {
  const query = searchInput.value.trim().toLowerCase();
  let visible = 0;
  gameCards.forEach(card => {
    const matchesQuery = card.dataset.name.toLowerCase().includes(query);
    const matchesFilter = activeFilter === 'All' || card.dataset.genre === activeFilter;
    const show = matchesQuery && matchesFilter;
    card.hidden = !show;
    if (show) visible++;
  });
  emptyState.hidden = visible !== 0;
}

searchInput.addEventListener('input', updateGames);
filterList.addEventListener('click', event => {
  const button = event.target.closest('[data-filter]');
  if (!button) return;
  activeFilter = button.dataset.filter;
  filterList.querySelectorAll('.filter-chip').forEach(chip => chip.classList.toggle('selected', chip === button));
  updateGames();
});

const modal = document.getElementById('gameModal');
const modalTitle = document.getElementById('modalTitle');
const modalDescription = document.getElementById('modalDescription');
function closeModal() { modal.hidden = true; }
document.getElementById('gamesGrid').addEventListener('click', event => {
  const button = event.target.closest('[data-game]');
  if (!button) return;
  const title = button.dataset.game;
  modalTitle.textContent = title;
  modalDescription.textContent = games[title] || 'Explore this game and discover what makes it special.';
  modal.hidden = false;
  document.getElementById('modalClose').focus();
});
document.getElementById('modalClose').addEventListener('click', closeModal);
document.getElementById('modalDone').addEventListener('click', closeModal);
modal.addEventListener('click', event => { if (event.target === modal) closeModal(); });
document.addEventListener('keydown', event => { if (event.key === 'Escape') closeModal(); });

const menuToggle = document.getElementById('menuToggle');
const mainNav = document.getElementById('mainNav');
menuToggle.addEventListener('click', () => {
  const isOpen = mainNav.classList.toggle('open');
  menuToggle.setAttribute('aria-expanded', String(isOpen));
  menuToggle.textContent = isOpen ? '×' : '☰';
});
mainNav.querySelectorAll('a').forEach(link => link.addEventListener('click', () => {
  mainNav.classList.remove('open');
  menuToggle.setAttribute('aria-expanded', 'false');
  menuToggle.textContent = '☰';
}));
document.getElementById('year').textContent = new Date().getFullYear();
